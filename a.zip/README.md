# Prusix

Soon

## Dependences:

- gcc
- nasm
- ld
- grub-mkrescue
- qemu-system-i386
- find

## Building:

```bash
cd build
make all clean run
```
